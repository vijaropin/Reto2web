//modelo
//interface
//repositorio
//servicio
//controlador


package Reto2_Web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Reto2WebApplication {

	public static void main(String[] args) {
		SpringApplication.run(Reto2WebApplication.class, args);
	}

}
